//
//  UIButton+timeDown.h
//  ScanPurse
//
//  Created by zenglizhi on 2018/3/14.
//  Copyright © 2018年 zenglizhi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIButton (timeDown)

- (void)checkTimeWithTimeId:(NSString *)timeId
                      title:(NSString *)title
             countDownTitle:(NSString *)subTitle;

- (void)startWithTime:(NSTimeInterval)timeLine
              maxTime:(NSTimeInterval)maxTime
                title:(NSString *)title
       countDownTitle:(NSString *)subTitle
               timeId:(NSString *)timeId;

- (void)startWithTime:(NSTimeInterval)timeLine
              maxTime:(NSTimeInterval)maxTime
                title:(NSString *)title
       countDownTitle:(NSString *)subTitle
            mainColor:(UIColor *)mColor
           countColor:(UIColor *)color
               timeId:(NSString *)timeId;
@end
